import { IsString, IsInt } from 'class-validator';

export class UpdateBookDto {
  @IsString()
  title: string;

  @IsString()
  author: string;

  @IsInt()
  year: number;
}
